package com.example.analytics;

import com.example.analytics.processor.Processor;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.AssertionErrors;
import org.springframework.util.Assert;

@SpringBootTest
public class AnalyticsApplicationTests {

    private final String content = "There .are. exactly .8. dots. in. this. text. my friend";

    @Autowired
    private Processor numberOfDotsProcessor;

    @Autowired
    private Processor numberOfWordsProcessor;

    @Autowired
    private Processor mostUsedWordProcessor;

    @Test
    void contextLoads() {
    }

    @Test
    public void testNumberOfDotsProcessor() {
        AssertionErrors.assertNotNull("Should not be null", numberOfDotsProcessor);
        Assert.isTrue(numberOfDotsProcessor.process(content).contains("8"), "The number 8 should be in the response");
    }

    @Test
    public void testNumberOfWordsProcessor() {
        AssertionErrors.assertNotNull("Should not be null", numberOfWordsProcessor);
        Assert.isTrue(numberOfWordsProcessor.process(content).contains("10"), "The number 10 should be in the response");
    }

    @Test
    public void testMostUsedWordProcessorWhenThereAreNoRepeatingWords() {
        AssertionErrors.assertNotNull("Should not be null", mostUsedWordProcessor);
        Assert.isTrue(mostUsedWordProcessor.process(content).contains("There are no repeating words"), "There are no repeating words at all");
    }

    @Test //1 instance of a repeated word
    public void testMostUsedWordProcessorWhenRepeatedWordIsOne() {
        AssertionErrors.assertNotNull("Should not be null", mostUsedWordProcessor);
        String result = mostUsedWordProcessor.process("According to JAVA experts, java is the coolest thing ever");
        Assert.isTrue(result.contains("JAVA"), "");
    }
}
