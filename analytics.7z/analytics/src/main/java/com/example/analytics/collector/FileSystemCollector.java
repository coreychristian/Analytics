package com.example.analytics.collector;

import org.springframework.stereotype.Component;

import java.io.File;
import java.util.Arrays;
import java.util.List;


@Component
public class FileSystemCollector  implements Collector {

    @Override
    public List<File> collect(String path) {
        File directory = new File(path);
        if (directory.isDirectory()) {
           return Arrays.asList(directory.listFiles());
        } else {
            throw new RuntimeException("Filepath is not to a directory");
        }
    }

    @Override
    public boolean move(File file, String newLocation) {
        if (file.exists()) {
            return file.renameTo(new File(newLocation));
        }
        return false;
    }
}
