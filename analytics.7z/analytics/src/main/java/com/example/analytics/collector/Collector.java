package com.example.analytics.collector;

import java.io.File;
import java.util.List;

public interface Collector {
    List<File> collect(String filePath);
    boolean move(File file, String newLocation);
}
