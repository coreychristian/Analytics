package com.example.analytics.processor;

public interface Processor {
    String process(String fileContent);
    //- You only need to provide support for calculating the number of words, number of dots and most used word in the file content.
}
