package com.example.analytics.handler;

import com.example.analytics.processor.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
public class TextFileHandler implements Handler {

    @Autowired
    private Processor mostUsedWordProcessor;

    @Autowired
    private Processor numberOfDotsProcessor;
    @Autowired
    private Processor numberOfWordsProcessor;

    private Set<Processor> processors = new HashSet<Processor>();


    @Override
    public boolean canHandle(String fileName) {
        return true;
    }

    @Override
    public String handle(File file) throws IOException {
        if (file.isFile()) {
            String result = "";
            processors.add(numberOfDotsProcessor);
            processors.add(numberOfWordsProcessor);

            FileInputStream inputStream = new FileInputStream(file);
            Writer writer = new StringWriter();

            char[] buffer = new char[1024];
            try {
                Reader reader = new BufferedReader(
                        new InputStreamReader(inputStream, "UTF-8"));
                int n;
                while ((n = reader.read(buffer)) != -1) {
                    writer.write(buffer, 0, n);
                }
            } finally {
                inputStream.close();
            }
            String fileContent = writer.toString();

            for (Processor processor : processors) {
                result += "  ";
                result += processor.process(fileContent);
            }
            return result;
        }
        return "";
    }
}
