package com.example.analytics.processor;

import org.springframework.stereotype.Component;

@Component
public class NumberOfDotsProcessor implements Processor {
    @Override //Quick way to do it if we are sure the file will be small enough, In production ready code I would use StringUtils to do the count for me
    public String process(String fileContent) {
        long originalLength = fileContent.length();
        long newFileLength = fileContent.replace(".", "").length();
        return "There are exactly " + (originalLength - newFileLength) +"dots (.) in the file";
    }
}
