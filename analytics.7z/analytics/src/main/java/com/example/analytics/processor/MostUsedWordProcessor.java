package com.example.analytics.processor;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class MostUsedWordProcessor implements Processor {
    @Override
    public String process(String fileContent) {
        long maxInstances = 0L;
        String result = "";

        for (String word : fileContent.split(" ")) {
            long wordInstance = StringUtils.countOccurrencesOf(fileContent, word);
            if ( wordInstance> maxInstances) {
                result = word;
                maxInstances = wordInstance;
            }
        }
        return "Most used word is " + result + "having " + maxInstances + " instances";
    }
//    @Override
//    public String process(String fileContent) {
//        //first split the document into an array so we can identify each individual word
//        String[] wordsInFile = fileContent.split(" ");
//        String mostUsedWord = "";
//        long maxWordOccurences = 0L;
////        List<String> wordsInFileList =Arrays.asList(wordsInFile);
//
//        for(String word : wordsInFile) {
//            long wordOccurences = 0L;
//            for(String iterationWord : wordsInFile) {
//                if (iterationWord.equalsIgnoreCase(word)) {//
//                    wordOccurences++;
//                    // ensure most used word is set when first encountered
//                    if (mostUsedWord.equalsIgnoreCase("")) {
//                        mostUsedWord = word;
//                        wordOccurences++;
//                    }
//
//                    //update most used word if necessary
//                    if (wordOccurences > maxWordOccurences) {
//                        maxWordOccurences = wordOccurences;
//                        mostUsedWord = word;
//                    }
//                }
//            }
//        }
//
//        if (wordsInFile.length > 1 && maxWordOccurences == 1) {
//            return "There are no repeating words";
//        }
//        return "The most used word is " + mostUsedWord;
//    }


}
