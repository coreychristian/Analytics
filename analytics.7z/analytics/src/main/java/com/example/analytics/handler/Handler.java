package com.example.analytics.handler;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public interface Handler {
    boolean canHandle(String fileName);

    String handle(File file) throws IOException;
}
