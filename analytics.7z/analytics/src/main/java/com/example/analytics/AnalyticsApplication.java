package com.example.analytics;

import com.example.analytics.collector.Collector;
import com.example.analytics.handler.Handler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.File;
import java.io.IOException;
import java.util.*;

@EnableScheduling
@SpringBootApplication
public class AnalyticsApplication {

    @Autowired
    private Collector fileSystemCollector;

    @Autowired
    private Handler textFileHandler;


    public static void main(String[] args) {
        SpringApplication.run(AnalyticsApplication.class, args);
    }

    @Scheduled(fixedRate = 5000)
    private void CollectAndProcess() throws IOException {
        Set<Handler> handlers = new HashSet<Handler>();
        handlers.add(textFileHandler);

        List<File> allFiles = fileSystemCollector.collect("src/main/resources/files"); //this would come from the console, or a config better yet
        if (allFiles.size() == 0) {
            System.out.println("Currently there are no new files to proccess");
        }
        for ( File file : allFiles) {
            for (Handler handler : handlers) {
                if (handler.canHandle(file.getName())) {
                    String result = handler.handle(file);
                    System.out.println(result);
                }
            }
            fileSystemCollector.move(file, "src/main/resources/files_processed/" + file.getName()); //again, configuration values would have been nicer
        }
    }
}
