package com.example.analytics.processor;

import org.springframework.stereotype.Component;

@Component
public class NumberOfWordsProcessor implements Processor {

    @Override
    public String process(String fileContent) { //again, a quick way to count the number of words in a file, that is assuming the document is formatted correctly, again there are libraries I would use in production code to achieve this
        long numberOfWords = fileContent.split(" ").length;
        return "There are exactly "+numberOfWords+" number of words in the file";
    }
}
