Unfortunately I have run out of time.

Here is my solution, classes listed below explaining what they do.

AnalyticsApplication -> Entry point into the application, my idea was to use a service approach, that would tie the collection of the files together with the processing. 
This would have made my code a little bit mode solid I feel. And also it would have included multiple collectors as my design suggests.
Here I also build a list of collectors, ideally I would have been able to automatically wire them in (by interface type), using spring, this way adding a new one, would mean that it just works (as my design idea suggested)
Lastly after processing, I tried to move the file, to a processed location, this would also have been better placed in the service, had I not run out of time.
On a 5000ms sechedule, this class tries to collect and process any files that may now appear in the folder

FileCollector, this class implements the collector interface, and does two things mainly, that is scrape a directory for any new files, and returns these files for processing, and it attempts 
to move processed files to anothert location so they no longer get processed.

Lastly the processor interface. this has numerous implementations, to implement the requred statistic functionality as required, the goal here was to make it as modular as possible
so that one could easilt add new statistic gathering criteria.

NumberOfWordsProcessor, simply splits the input string into an array, and counts the number of elements and returns a string that will be displayed in the console.
NumberofDots Processor, here I counted the number of words, then subtraced all the dots and counted again, subtracting the new value from the original, gave me the number of dots.
MostUsedWordProcessor, perhaps the most challenging part of the excercise for me, here I attempted to track each word occurence, by iterating through the collection of words, I ended up abandoning this 
approach so I could get the rest of the excercise complete in the time that I had. But I am confident that I can get it right by just spending a little more time on it. (I left the commented out code, 
which I abandoned, to highlight my idea before abandoning it).

AnalyticsApplicationTests class, there to show you my idea's on unit testing, I intially went with a test driven approach, but you will find I stopped writing tests as I began to run short on time
I feel I spent too much time trying to figure out what was wrong with my word occurence count, I was really enjoying the challenge.